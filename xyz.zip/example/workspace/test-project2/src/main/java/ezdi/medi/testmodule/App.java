package ezdi.medi.testmodule;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "this is new project" );
    }
}
